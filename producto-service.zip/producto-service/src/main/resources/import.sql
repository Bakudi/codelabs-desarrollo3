INSERT INTO producto (nombre, descripcion, precio) VALUES ('Producto 1', 'Descripcion 1', 100);
INSERT INTO producto (nombre, descripcion, precio) VALUES ('Producto 2', 'Descripcion 2', 200);
INSERT INTO producto (nombre, descripcion, precio) VALUES ('Producto 3', 'Descripcion 3', 300);
INSERT INTO producto (nombre, descripcion, precio) VALUES ('Producto 4', 'Descripcion 4', 400);
INSERT INTO producto (nombre, descripcion, precio) VALUES ('Producto 5', 'Descripcion 5', 500);